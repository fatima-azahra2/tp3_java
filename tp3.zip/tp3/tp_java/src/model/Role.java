package model;

public enum Role {
    ADMIN, EMPLOYEE ,MANAGER
}