
module tp_java {
	requires java.sql;
	requires java.desktop;
}